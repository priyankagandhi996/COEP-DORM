from django.forms import ModelForm
from app1.models import CoepHostel,Signup

# Create the form class.
class SignupForm(ModelForm):
    class Meta:
        model = Signup
        fields = ['c_id','email','password']


            


    def clean(self):
        cleaned_data = super(SignupForm, self).clean()
        c_id = cleaned_data.get('c_id')
        email = cleaned_data.get('email')
        password = cleaned_data.get('password')
        
        if not c_id and not email and not password:
            raise forms.ValidationError('You have to write something!')
