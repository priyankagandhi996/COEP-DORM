from django.shortcuts import render,get_object_or_404
from .models import CoepHostel,Signup
from django.contrib.auth.forms import UserCreationForm
from .forms import SignupForm

def signup(request, template_name='signup.html', form_class=SignupForm):
	if request.method == 'POST':
		form = form_class(request.POST)
		if form.is_valid():
			c_id = request.POST.get('c_id','')
			email = request.POST.get('email','')
			password = request.POST.get('password','')
			password1 = request.POST.get('password1','')

			try:
				go1 = Signup.objects.get(c_id=c_id)
			except Exception as e:
				go1 = None
			if go1 != None:
				con = "***College Id Already Exists***"
				return render(request,"signup.html",{'con':con}) 				
				

			try:
				go = CoepHostel.objects.get(c_id=c_id)
			except Exception as e:
				con = "***College Id Does Not Exist***"
				return render(request,"signup.html",{'con':con}) 
			else:
				if go.email == email :
					if password==password1 :
						s_obj = Signup(c_id = c_id , email = email , password = password )
						s_obj.save()
						return render(request,"home.html",)
					else :
						con = "***Password Is Not Matching***"
						return render(request,"signup.html",{'con':con}) 
				else :
					con = "***Email Is Not Matching***"
					return render(request,"signup.html",{'con':con}) 
			finally:
				pass
			#pass  # does nothing, just trigger the validation
	else:
		form = form_class()
	return render(request, template_name, {'form': form})

